#ifndef USUARIOS_H
#define USUARIOS_H

int registrarUsuario();
int loginUsuario();
int validarCedula(const char *cedula);
int validarContrasena(const char *contrasena);

#endif
