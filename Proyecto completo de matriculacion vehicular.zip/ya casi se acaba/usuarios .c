#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include "usuarios.h"

extern char usuarioActual[100];  // declarado en main.c

static const char *RUTA_USUARIOS = "usuarios.txt";  // en Documents

static char *rutaEnDocuments(char *buffer, size_t buflen) {
	char *home = getenv("USERPROFILE");
	if (!home) return NULL;
	snprintf(buffer, buflen, "%s\\Documents\\%s", home, RUTA_USUARIOS);
	return buffer;
}

static void pausar(void) {
	printf("\nPresione Enter para continuar...");
	while (getchar() != '\n');
}

int validarCedula(const char *cedula) {
	if (strlen(cedula) != 10) return 0;
	for (int i = 0; i < 10; i++) {
		if (!isdigit((unsigned char)cedula[i])) return 0;
	}
	return 1;
}

int validarContrasena(const char *contrasena) {
	int len = strlen(contrasena);
	return (len >= 5 && len <= 20);
}

int cedulaExiste(const char* cedula) {
	char linea[150], cedulaArchivo[20];
	char ruta[300];
	if (!rutaEnDocuments(ruta, sizeof(ruta))) return 0;
	FILE *archivo = fopen(ruta, "r");
	if (!archivo) return 0;
	while (fgets(linea, sizeof(linea), archivo)) {
		if (sscanf(linea, "Cedula: %19[^,], Contrasena: %*s", cedulaArchivo) == 1) {
			if (strcmp(cedulaArchivo, cedula) == 0) {
				fclose(archivo);
				return 1;
			}
		}
	}
	fclose(archivo);
	return 0;
}

int registrarUsuario(void) {
	char cedula[20], contrasena[25], confirmar[25];
	char ruta[300];
	if (!rutaEnDocuments(ruta, sizeof(ruta))) {
		printf("Error: ruta de usuarios no disponible.\n");
		pausar();
		return 0;
	}
	
	for (int intentos = 1; intentos <= 3; intentos++) {
		printf("\nRegistro de Usuario (Intento %d de 3)\n", intentos);
		printf("Cedula (10 digitos): "); 
		scanf("%19s", cedula); while (getchar()!='\n');
		if (!validarCedula(cedula)) {
			printf("Cedula inv�lida.\n"); continue;
		}
		if (cedulaExiste(cedula)) {
			printf("Cedula ya registrada.\n"); continue;
		}
		printf("Contrasena (5-20 caracteres): "); 
		scanf("%24s", contrasena); while (getchar()!='\n');
		if (!validarContrasena(contrasena)) {
			printf("Contrasena inv�lida.\n"); continue;
		}
		printf("Confirmar contrasena: ");
		scanf("%24s", confirmar); while (getchar()!='\n');
		if (strcmp(contrasena, confirmar) != 0) {
			printf("No coinciden contrasenas.\n"); continue;
		}
		
		FILE *archivo = fopen(ruta, "a");
		if (!archivo) {
			printf("Error al abrir archivo de usuarios.\n"); pausar(); return 0;
		}
		fprintf(archivo, "Cedula: %s, Contrasena: %s\n", cedula, contrasena);
		fclose(archivo);
		printf("Registro exitoso.\n"); 
		return 1;
	}
	printf("Fallaron los intentos de registro.\n"); pausar();
	return 0;
}

int loginUsuario(void) {
	char cedula[20], contrasena[25], linea[150];
	char cedulaArchivo[20], contrasenaArchivo[25];
	char ruta[300];
	if (!rutaEnDocuments(ruta, sizeof(ruta))) {
		printf("Error: ruta de usuarios no disponible.\n");
		pausar();
		return 0;
	}
	
	for (int intentos = 1; intentos <= 3; intentos++) {
		printf("\nInicio de Sesion (Intento %d de 3)\n", intentos);
		printf("Cedula: "); scanf("%19s", cedula); while (getchar()!='\n');
		printf("Contrasena: "); scanf("%24s", contrasena); while (getchar()!='\n');
		
		FILE *archivo = fopen(ruta, "r");
		if (!archivo) {
			printf("No existe archivo de usuarios.\n"); pausar(); return 0;
		}
		int encontrado = 0;
		while (fgets(linea, sizeof(linea), archivo)) {
			if (sscanf(linea, "Cedula: %19[^,], Contrasena: %24s", cedulaArchivo, contrasenaArchivo) == 2) {
				if (strcmp(cedulaArchivo, cedula) == 0 && strcmp(contrasenaArchivo, contrasena) == 0) {
					encontrado = 1;
					break;
				}
			}
		}
		fclose(archivo);
		if (encontrado) {
			strcpy(usuarioActual, cedula);
			
			return 1;
		}
		printf("Credenciales incorrectas.\n"); pausar();
	}
	printf("Agotados intentos de inicio de sesion.\n"); pausar();
	return 0;
}
