#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "usuarios.h"
#include "entrada.h"
#include "estructuras.h"
#include "calculos.h"

char usuarioActual[100];  // Usuario logueado

void pausar() {
	printf("\nPresione Enter para continuar...");
	getchar(); getchar();
}

void mostrarMenu() {
	printf("\n===== MENU PRINCIPAL =====\n");
	printf("1. Registrar un vehiculo nuevo\n");
	printf("2. Buscar vehiculo\n");
	printf("3. Calcular valor de matricula\n");
	printf("4. Listar vehiculos matriculados\n");
	printf("5. Salir\n");
	printf("Seleccione una opcion: ");
}

void buscarVehiculo() {
	char placaBuscada[10], linea[200];
	int intentos = 3, encontrado = 0;
	
	while (intentos--) {
		printf("\nIngrese la placa del vehiculo: ");
		scanf("%s", placaBuscada);
		while (getchar() != '\n');
		
		char* carpeta = getenv("USERPROFILE");
		if (carpeta != NULL) {
			char ruta[200];
			sprintf(ruta, "%s\\Documents\\vehiculos_matriculados.txt", carpeta);
			FILE* archivo = fopen(ruta, "r");
			if (archivo == NULL) {
				printf("Error al abrir el archivo de vehiculos.\n");
				return;
			}
			
			int leer = 0;
			while (fgets(linea, sizeof(linea), archivo)) {
				if (strstr(linea, "Usuario: ") && strstr(linea, usuarioActual)) {
					leer = 1;
				}
				if (leer && strstr(linea, placaBuscada)) {
					encontrado = 1;
					printf("\n--- Vehiculo encontrado ---\n");
					printf("%s", linea);
					for (int i = 0; i < 5 && fgets(linea, sizeof(linea), archivo); i++) {
						printf("%s", linea);
					}
					break;
				}
			}
			fclose(archivo);
		}
		
		if (encontrado) break;
		printf("Vehiculo no encontrado o no pertenece a su cuenta.\n");
	}
	
	if (!encontrado) {
		printf("No se encontraron coincidencias tras 3 intentos. Regresando al menu.\n");
	}
	pausar();
	system("cls");
}

void calcularMatriculaDesdeRegistro() {
	char* carpeta = getenv("USERPROFILE");
	char ruta[200], linea[200];
	sprintf(ruta, "%s\\Documents\\vehiculos_matriculados.txt", carpeta);
	FILE* archivo = fopen(ruta, "r");
	
	if (archivo == NULL) {
		printf("Error al abrir el archivo de vehiculos.\n");
		pausar();
		system("cls");
		return;
	}
	
	int mostrar = 0, contador = 0;
	Vehiculo v;
	
	printf("\n--- Calculo de matricula para sus vehiculos registrados ---\n");
	
	while (fgets(linea, sizeof(linea), archivo)) {
		if (strstr(linea, "Usuario: ") && strstr(linea, usuarioActual)) {
			mostrar = 1;
		} else if (strstr(linea, "Usuario: ") && !strstr(linea, usuarioActual)) {
			mostrar = 0;
		}
		
		if (mostrar) {
			if (strstr(linea, "Placa: ")) sscanf(linea, "Placa: %s", v.placa);
			if (strstr(linea, "Edad: ")) sscanf(linea, "Edad: %d", &v.edad);
			if (strstr(linea, "Avaluo: ")) sscanf(linea, "Avaluo: %f", &v.avaluo);
			if (strstr(linea, "Cilindraje: ")) sscanf(linea, "Cilindraje: %f", &v.cilindraje);
			if (strstr(linea, "Anio de fabricacion: ")) sscanf(linea, "A%cno de fabricacion: %d", &v.anioFabricacion);
			
			if (strstr(linea, "------------------------------")) {
				contador++;
				
				// Calculo
				float impuesto = calcular_impuesto_vehiculo(v.avaluo);
				float sppat = calcular_sppat((int)v.cilindraje, 2025 - v.anioFabricacion);
				float rodaje = calcular_rodaje_provincial((int)v.cilindraje);
				float recargo = calcular_recargo(2); // ejemplo
				float costo_placa = calcular_costo_placa(0);
				float total = calcular_total(impuesto, sppat, 0.0, rodaje, 0.0, recargo, costo_placa, v.edad);
				
				// Mostrar
				printf("\nVehiculo #%d\n", contador);
				printf("Placa: %s\n", v.placa);
				printf("Edad del propietario: %d\n", v.edad);
				printf("Avaluo: %.2f\n", v.avaluo);
				printf("Cilindraje: %.1f\n", v.cilindraje);
				printf("A%co de fabricacion: %d\n", 164, v.anioFabricacion);
				
				printf("Impuesto: %.2f | SPPAT: %.2f | Rodaje: %.2f | Recargo: %.2f | Total: %.2f\n",
					   impuesto, sppat, rodaje, recargo, total);
			}
		}
	}
	
	fclose(archivo);
	
	if (contador == 0) {
		printf("\nPrimero registre un vehiculo en la opcion 1.\n");
	}
	
	pausar();
	system("cls");
}

void listarVehiculosUsuario() {
	char* carpeta = getenv("USERPROFILE");
	char ruta[200], linea[200], placa[20];
	sprintf(ruta, "%s\\Documents\\vehiculos_matriculados.txt", carpeta);
	FILE* archivo = fopen(ruta, "r");
	int imprimir = 0;
	
	if (archivo == NULL) {
		printf("No hay vehiculos registrados.\n");
		pausar();
		system("cls");
		return;
	}
	
	printf("\n--- Lista de placas de sus vehiculos ---\n");
	while (fgets(linea, sizeof(linea), archivo)) {
		if (strstr(linea, "Usuario: ") && strstr(linea, usuarioActual)) {
			imprimir = 1;
		}
		if (imprimir && strstr(linea, "Placa: ")) {
			sscanf(linea, "Placa: %s", placa);
			printf("� %s\n", placa);
			imprimir = 0;
		}
	}
	fclose(archivo);
	pausar();
	system("cls");
}

int main() {
	int opcionlog;
	int sesionIniciada = 0;
	Vehiculo vehiculo;
	int opcion;
	
	system("cls");
	
	// ==== LOGIN Y REGISTRO ====
	do {
		printf("\n===== Matriculacion Vehicular =====\n");
		printf("1. Iniciar sesion\n");
		printf("2. Registrarse\n");
		printf("3. Salir\n");
		printf("Seleccione una opcion: ");
		scanf("%d", &opcionlog);
		while (getchar() != '\n');
		
		system("cls");
		
		switch (opcionlog) {
		case 1:
			sesionIniciada = loginUsuario(usuarioActual);
			system("cls");
			break;
		case 2:
			registrarUsuario();
			pausar();
			system("cls");
			break;
		case 3:
			printf("Saliendo del programa...\n");
			return 0;
		default:
			printf("Opcion no valida.\n");
			pausar();
			system("cls");
		}
	} while (!sesionIniciada);
	
	// ==== MENU PRINCIPAL ====
	printf("Usuario correcto, bienvenido %s\n", usuarioActual);
	
	do {
		mostrarMenu();
		scanf("%d", &opcion);
		while (getchar() != '\n');
		
		system("cls");
		
		switch (opcion) {
		case 1:
			if (!obtenerDatosVehiculo(&vehiculo)) {
				printf("Proceso cancelado por datos invalidos.\n");
			} else {
				printf("\n--- Datos ingresados correctamente ---\n");
				printf("Placa: %s\n", vehiculo.placa);
				printf("Edad del propietario: %d\n", vehiculo.edad);
				printf("Avaluo del vehiculo: %.2f\n", vehiculo.avaluo);
				printf("Cilindraje: %.1f\n", vehiculo.cilindraje);
				printf("A%co de fabricacion: %d\n", 164, vehiculo.anioFabricacion);
				
				char* carpeta = getenv("USERPROFILE");
				if (carpeta != NULL) {
					char ruta[200];
					sprintf(ruta, "%s\\Documents\\vehiculos_matriculados.txt", carpeta);
					FILE* archivo = fopen(ruta, "a");
					if (archivo != NULL) {
						fprintf(archivo,
								"Usuario: %s\nPlaca: %s\nEdad: %d\nAvaluo: %.2f\nCilindraje: %.1f\nA%co de fabricacion: %d\n------------------------------\n",
								usuarioActual, vehiculo.placa, vehiculo.edad,
								vehiculo.avaluo, vehiculo.cilindraje, 164, vehiculo.anioFabricacion);
						fclose(archivo);
						printf("Datos guardados correctamente en: %s\n", ruta);
					} else {
						printf("Error al guardar el archivo.\n");
					}
				}
			}
			pausar();
			system("cls");
			break;
			
		case 2:
			buscarVehiculo();
			break;
			
		case 3:
			calcularMatriculaDesdeRegistro();
			break;
			
		case 4:
			listarVehiculosUsuario();
			break;
			
		case 5:
			printf("Saliendo del programa...\n");
			break;
			
		default:
			printf("Opcion invalida. Intente de nuevo.\n");
			pausar();
			system("cls");
		}
	} while (opcion != 5);
	
	return 0;
}
