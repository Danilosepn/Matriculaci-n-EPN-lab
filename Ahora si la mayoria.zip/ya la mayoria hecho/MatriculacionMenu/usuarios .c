#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include "usuarios.h"

int validarCedula(const char *cedula) {
	if (strlen(cedula) != 10) return 0;
	for (int i = 0; i < 10; i++) {
		if (!isdigit(cedula[i])) return 0;
	}
	return 1;
}

int validarContrasena(const char *contrasena) {
	int len = strlen(contrasena);
	return (len >= 5 && len <= 20);
}

void limpiarPantalla() {
	system("cls");
}

int registrarUsuario() {
	char cedula[20], contrasena[25], confirmar[25];
	char rutaArchivo[300];
	char *carpUsua = getenv("USERPROFILE");
	int intentos = 0;
	
	if (carpUsua == NULL) {
		fprintf(stderr, "No se pudo obtener la variable USERPROFILE\n");
		return 0;
	}
	
	snprintf(rutaArchivo, sizeof(rutaArchivo),
			 "%s\\Documents\\vehiculos_matriculados.txt", carpUsua);
	
	while (intentos < 3) {
		limpiarPantalla();
		printf("Registro de Usuario (Intento %d de 3)\n", intentos + 1);
		printf("Numero de cedula (10 digitos): ");
		scanf("%s", cedula);
		if (!validarCedula(cedula)) {
			printf("Cedula invalida. Debe contener solo 10 digitos.\n");
			intentos++;
			continue;
		}
		
		printf("Contrasena (5 a 20 caracteres) : ");
		scanf("%s", contrasena);
		if (!validarContrasena(contrasena)) {
			printf("Contrasena invalida. Debe tener entre 10 y 20 caracteres.\n");
			intentos++;
			continue;
		}
		
		printf("Confirmar contrasena: ");
		scanf("%s", confirmar);
		if (strcmp(contrasena, confirmar) != 0) {
			printf("Las contrasenas no coinciden.\n");
			intentos++;
			continue;
		}
		
		FILE *archivo = fopen(rutaArchivo, "a");
		if (!archivo) {
			printf("Error al abrir archivo de usuarios.\n");
			return 0;
		}
		
		fprintf(archivo, "Cedula: %s, Contrasena: %s\n", cedula, contrasena);
		fclose(archivo);
		printf("Registro exitoso.\n");
		return 1;
	}
	
	printf("Se han agotado los intentos para registrar el usuario.\n");
	return 0;
}

int loginUsuario() {
	char cedula[20], contrasena[25], linea[150];
	int encontrado = 0;
	char rutaArchivo[300];
	char *carpUsua = getenv("USERPROFILE");
	int intentos = 0;
	
	if (carpUsua == NULL) {
		fprintf(stderr, "No se pudo obtener la variable USERPROFILE\n");
		return 0;
	}
	
	snprintf(rutaArchivo, sizeof(rutaArchivo),
			 "%s\\Documents\\vehiculos_matriculados.txt", carpUsua);
	
	while (intentos < 3) {
		limpiarPantalla();
		printf("Inicio de Sesion (Intento %d de 3)\n", intentos + 1);
		printf("Ingrese numero de cedula: ");
		scanf("%s", cedula);
		printf("Contrasena: ");
		scanf("%s", contrasena);
		
		FILE *archivo = fopen(rutaArchivo, "r");
		if (!archivo) {
			printf("No se encontro el archivo de usuarios.\n");
			return 0;
		}
		
		while (fgets(linea, sizeof(linea), archivo)) {
			char cedulaArchivo[20], contrasenaArchivo[25];
			if (sscanf(linea, "Cedula: %[^,], Contrasena: %[^\n]", cedulaArchivo, contrasenaArchivo) == 2) {
				if (strcmp(cedulaArchivo, cedula) == 0 && strcmp(contrasenaArchivo, contrasena) == 0) {
					encontrado = 1;
					break;
				}
			}
		}
		fclose(archivo);
		
		if (encontrado) {
			printf("Inicio de sesion exitoso.\n");
			return 1;
		} else {
			printf("Cedula o contrasena incorrectas.\n");
			intentos++;
		}
	}
	
	printf("Se han agotado los intentos para iniciar sesion.\n");
	return 0;
}
