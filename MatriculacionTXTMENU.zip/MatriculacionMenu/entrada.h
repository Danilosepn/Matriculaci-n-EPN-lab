#ifndef ENTRADA_H
#define ENTRADA_H

#include "estructuras.h"

int obtenerDatosVehiculo(Vehiculo* v);

#endif