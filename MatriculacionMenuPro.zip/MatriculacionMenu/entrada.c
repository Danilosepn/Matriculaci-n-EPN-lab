#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "entrada.h"
#include "validaciones.h"

#define INTENTOS_MAX 3

int obtenerDatosVehiculo(Vehiculo* v) {
	int intentosRestantes;
	char buffer[50];
	
	// PLACA
	intentosRestantes = INTENTOS_MAX;
	while (intentosRestantes > 0) {
		system("cls");
		if (strlen(v->placa) > 0)
			printf("Placa ya ingresada: %s\n", v->placa);
		printf("Placa del vehiculo (Intentos restantes: %d): ", intentosRestantes);
		scanf("%s", buffer); while (getchar() != '\n');
		if (esPlacaValida(buffer)) {
			strcpy(v->placa, buffer);
			break;
		}
		printf("Placa invalida.\n");
		intentosRestantes--;
	}
	if (intentosRestantes == 0) return 0;
	
	// PROVINCIA
	intentosRestantes = INTENTOS_MAX;
	while (intentosRestantes > 0) {
		system("cls");
		printf("Placa: %s\n", v->placa);
		printf("Provincia (Intentos restantes: %d): ", intentosRestantes);
		scanf("%s", buffer); while (getchar() != '\n');
		if (esNombreValido(buffer)) {
			strcpy(v->provincia, buffer);
			break;
		}
		printf("Provincia invalida.\n");
		intentosRestantes--;
	}
	if (intentosRestantes == 0) return 0;
	
	// EDAD
	intentosRestantes = INTENTOS_MAX;
	while (intentosRestantes > 0) {
		system("cls");
		printf("Placa: %s | Provincia: %s\n", v->placa, v->provincia);
		printf("Edad del propietario (Intentos restantes: %d): ", intentosRestantes);
		if (scanf("%d", &v->edad) == 1 && v->edad > 0) {
			while (getchar() != '\n');
			break;
		}
		printf("Edad invalida.\n");
		while (getchar() != '\n');
		intentosRestantes--;
	}
	if (intentosRestantes == 0) return 0;
	
	// AVALUO
	intentosRestantes = INTENTOS_MAX;
	while (intentosRestantes > 0) {
		system("cls");
		printf("Placa: %s | Provincia: %s | Edad: %d\n", v->placa, v->provincia, v->edad);
		printf("Avaluo del vehiculo (USD) (Intentos restantes: %d): ", intentosRestantes);
		
		if (scanf("%f", &v->avaluo) == 1 && v->avaluo > 0 && v->avaluo <= 10000000) {
			while (getchar() != '\n');
			break;
		}
		
		printf("Avaluo invalido. Debe ser un n�mero mayor a 0 y menor o igual a 10,000,000.\n");
		while (getchar() != '\n');
		intentosRestantes--;
	}
	
	if (intentosRestantes == 0) return 0;
	
	
	// CILINDRAJE
	intentosRestantes = INTENTOS_MAX;
	while (intentosRestantes > 0) {
		system("cls");
		printf("Placa: %s | Provincia: %s | Edad: %d | Avaluo: %.2f\n",
			   v->placa, v->provincia, v->edad, v->avaluo);
		printf("Cilindraje (Intentos restantes: %d): ", intentosRestantes);
		if (scanf("%f", &v->cilindraje) == 1 && v->cilindraje > 0) {
			while (getchar() != '\n');
			break;
		}
		printf("Cilindraje invalido.\n");
		while (getchar() != '\n');
		intentosRestantes--;
	}
	if (intentosRestantes == 0) return 0;
	
	// A�O DE FABRICACI�N
	intentosRestantes = INTENTOS_MAX;
	while (intentosRestantes > 0) {
		system("cls");
		printf("Placa: %s | Provincia: %s | Edad: %d | Avaluo: %.2f | Cilindraje: %.1f\n",
			   v->placa, v->provincia, v->edad, v->avaluo, v->cilindraje);
		printf("A%co de fabricacion (Intentos restantes: %d): ", 164, intentosRestantes);
		if (scanf("%d", &v->anioFabricacion) == 1 &&
			v->anioFabricacion >= 1900 && v->anioFabricacion <= 2025) {
			while (getchar() != '\n');
			break;
		}
		printf("A%co invalido.\n", 164);
		while (getchar() != '\n');
		intentosRestantes--;
	}
	if (intentosRestantes == 0) return 0;
	
	return 1;
}
