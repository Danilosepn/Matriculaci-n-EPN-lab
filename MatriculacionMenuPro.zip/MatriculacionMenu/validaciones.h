#ifndef VALIDACIONES_H
#define VALIDACIONES_H

int esNombreValido(const char* texto);
int esNumeroValido(const char* texto);
int esPlacaValida(const char* placa);

#endif
