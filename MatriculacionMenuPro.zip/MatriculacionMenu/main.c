#include <stdio.h>
#include <stdlib.h>
#include "entrada.h"
#include "estructuras.h"

void mostrarMenu() {
	printf("\n===== MENU PRINCIPAL =====\n");
	printf("1. Registrar un vehiculo nuevo\n");
	printf("2. Buscar vehiculo\n");
	printf("3. Calcular valor de matr�cula\n");
	printf("4. Listar veh�culos matriculados\n");
	printf("5. Salir\n");
	printf("Seleccione una opcion: ");
	}
	


void pausar() {
	printf("\nPresione Enter para continuar...");
	getchar();
}

int main() {
	int opcion;
	Vehiculo vehiculo;
	
	do {
		mostrarMenu();
		scanf("%d", &opcion);
		while (getchar() != '\n');
		
		switch (opcion) {
		case 1:
			if (!obtenerDatosVehiculo(&vehiculo)) {
				printf("Proceso cancelado por datos invalidos.\n");
			} else {
				printf("\n--- Datos ingresados correctamente ---\n");
				printf("Placa: %s\n", vehiculo.placa);
				printf("Edad del propietario: %d\n", vehiculo.edad);
				printf("Avaluo del vehiculo: %.2f\n", vehiculo.avaluo);
				printf("Cilindraje: %.1f\n", vehiculo.cilindraje);
				printf("A%cno de fabricacion: %d\n", 164, vehiculo.anioFabricacion);
				
				// Guardar datos en archivo vehiculos_matriculados.txt
				char* carpeta = getenv("USERPROFILE");
				if (carpeta != NULL) {
					char ruta[200];
					sprintf(ruta, "%s\\Documents\\vehiculos_matriculados.txt", carpeta);
					FILE* archivo = fopen(ruta, "a");
					if (archivo != NULL) {
						fprintf(archivo,
								"Placa: %s\nProvincia: %s\nEdad: %d\nAvaluo: %.2f\nCilindraje: %.1f\nA�o de fabricaci�n: %d\n------------------------------\n",
								vehiculo.placa, vehiculo.provincia, vehiculo.edad,
								vehiculo.avaluo, vehiculo.cilindraje, vehiculo.anioFabricacion);
						
						fclose(archivo);
						printf("Datos guardados correctamente en: %s\n", ruta);
					} else {
						printf("Error al guardar el archivo.\n");
					}
				}
			}
			pausar();
			system("cls");
			break;
			
		case 2:
			printf("\nFuncion de busqueda no implementada aun.\n");
			pausar();
			system("cls");
			break;
			
		case 5:
			printf("Saliendo del programa...\n");
			break;
			
		default:
			printf("Opcion invalida. Intente de nuevo.\n");
			pausar();
			system("cls");
		}
	} while (opcion != 5);
	
	return 0;
}

