#ifndef ESTRUCTURAS_H
#define ESTRUCTURAS_H

typedef struct {
    char placa[10];
    char provincia[30];
    int edad;
    float avaluo;
    float cilindraje;
    int anioFabricacion;
} Vehiculo;

#endif
